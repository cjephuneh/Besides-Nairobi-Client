exports.id = 700;
exports.ids = [700];
exports.modules = {

/***/ 1161:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3100, 23))

/***/ }),

/***/ 5090:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4896))

/***/ }),

/***/ 4148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ sidebar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(4834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/assets/shape-x1.png
/* harmony default export */ const shape_x1 = ({"src":"/_next/static/media/shape-x1.1fcb564d.png","height":653,"width":1220,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAgElEQVR42mNAB9MbsyTXVeWodhSnh3eXZRQy3LA0D+sWE/ZlEBaIZWBgkMyNDK6v8HRty/Dx7vGN8JjMcMrUeH62IF9/iYxUy1JL85i1YlKhCxkYYpbxcUUuZWAJZ2AQ4KtiEBVuP6koN+mqs+OkixamHRcUZBZcMjPpuKClPgkAflsl05lRXV0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
// EXTERNAL MODULE: ./app/layout.js
var layout = __webpack_require__(2756);
;// CONCATENATED MODULE: ./app/components/sidebar.js






const Navbar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "flex items-center justify-between space-x-8 flex-wrap bg-white shadow-lg p-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex items-center flex-shrink-0 mr-[200px] aboslute ml-auto",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: shape_x1,
                    alt: "logo",
                    width: 100,
                    height: 100,
                    className: "ml-[150px]"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "block lg:hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "flex items-center px-3 py-2 border rounded text-gray-200 border-gray-400 hover:text-white hover:border-white",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                        className: "fill-current h-3 w-3",
                        viewBox: "0 0 20 20",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("title", {
                                children: "Menu"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M0 3h20v2H0zM0 9h20v2H0zM0 15h20v2H0z"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full block flex-grow lg:flex lg:items-center lg:w-auto ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-lg lg:flex-grow",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0 text-black hover:text-red-500  mr-4",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/about",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0  text-black hover:text-red-500  mr-4",
                                children: "About"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/CFP",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0  text-black hover:text-red-500  mr-4",
                                children: "Call for Papers"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/speakers",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0  text-black hover:text-red-500 mr-4",
                                children: "Speakers"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/schedule",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0  text-black hover:text-red-500  mr-4",
                                children: "Schedule"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/volunteer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0  text-black hover:text-red-500  mr-4",
                                children: "Volunteer"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/archives",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0  text-black hover:text-red-500  mr-4",
                                children: "Archives"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/code-of-conduct",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "block mt-4 lg:inline-block lg:mt-0  text-black hover:text-red-500 ",
                                children: "Code of Conduct"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const sidebar = (Navbar);


/***/ }),

/***/ 2756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(736);
/* harmony import */ var next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2817);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_components_sidebar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4148);




const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
            className: (next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3___default().className),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_sidebar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                children
            ]
        })
    });
}


/***/ }),

/***/ 4896:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/shape-x1.1fcb564d.png","height":653,"width":1220,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAgElEQVR42mNAB9MbsyTXVeWodhSnh3eXZRQy3LA0D+sWE/ZlEBaIZWBgkMyNDK6v8HRty/Dx7vGN8JjMcMrUeH62IF9/iYxUy1JL85i1YlKhCxkYYpbxcUUuZWAJZ2AQ4KtiEBVuP6koN+mqs+OkixamHRcUZBZcMjPpuKClPgkAflsl05lRXV0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 3174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 2817:
/***/ (() => {



/***/ })

};
;