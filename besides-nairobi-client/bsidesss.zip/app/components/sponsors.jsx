import React from 'react'

function sponsors() {
  return (
    <div>
      
    </div>
  )
}

export default sponsors
